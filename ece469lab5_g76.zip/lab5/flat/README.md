# Lab 5 Group 76
Kevin Shi
Michael Kolb
Sam Butchko

Lab 5 implements the DLXOS filesystem, also known as DFS, as well as other related file functionalities.

## Instructions

1. First compile the os by navigating to the ```os``` directory, and running ```make```. Upon doing that navigate to apps/fdisk and run ```make``` followed by ```make run``` to create the filesystem. The filesystem can be inspected using blockprint. This filesystem is what we're going to be using throughout the entire lab.
2. For q4, recompile the os as shown above. Then go to apps/ostests, and type ```make``` and ```make run```.
3. For q5 and q6 recomplie the os as shown above. Then go to apps/q6 and type ```make``` and ```make run```.

##Issues
We ran into some issues with q4 and q6 testing, the overall functionality was working but we ran into some issues with just debugging common errors.
