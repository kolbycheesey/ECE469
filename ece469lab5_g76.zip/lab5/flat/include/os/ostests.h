#ifndef __OS_TESTS__
#define __OS_TESTS__

void RunOSTests();

#endif
